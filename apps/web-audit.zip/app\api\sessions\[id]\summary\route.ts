// apps/web/app/api/sessions/[id]/summary/route.ts
import { NextResponse } from 'next/server';
import { getSupabaseServer } from '@/lib/supabaseServer';

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const supabase = await getSupabaseServer(); // ✅ await

  const { data: { user }, error: userErr } = await supabase.auth.getUser();
  if (userErr) return NextResponse.json({ error: userErr.message }, { status: 500 });
  if (!user)   return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const sessionId = (params.id ?? '').trim();

  // 쿼리 단계에서 바로 owner check
  const { data: row, error } = await supabase
    .from('v_session_score')
    .select('*')
    .eq('session_id', sessionId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (error)  return NextResponse.json({ error: error.message }, { status: 400 });
  if (!row)   return NextResponse.json({ error: 'not found' }, { status: 404 });

  return NextResponse.json(row, { status: 200 });
}
