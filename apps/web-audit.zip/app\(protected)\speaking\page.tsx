export default function SpeakingPage() {
return (
<div className="space-y-4">
<h1 className="text-2xl font-semibold">Speaking</h1>
<div className="rounded-2xl border bg-white p-4">준비 중…</div>
</div>
);
}