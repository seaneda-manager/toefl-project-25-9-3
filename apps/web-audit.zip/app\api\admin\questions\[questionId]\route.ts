import { NextResponse } from 'next/server';
import { getSupabaseServer } from '@/lib/supabaseServer';

export async function GET(_: Request, { params }: { params: { questionId: string } }) {
  const supabase = await getSupabaseServer();
  const { data, error } = await supabase.from('questions').select('*').eq('id', params.questionId).single();
  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  return NextResponse.json(data);
}

export async function PATCH(req: Request, { params }: { params: { questionId: string } }) {
  const supabase = await getSupabaseServer();
  const body = await req.json();
  const { data, error } = await supabase
    .from('questions')
    .update({
      number: body.number ?? 0,
      type: body.type,
      stem: body.stem,
      explanation: body.explanation ?? null,
      clue_quote: body.clue_quote ?? null,
      order_index: body.order_index ?? 0,
    })
    .eq('id', params.questionId)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

export async function DELETE(_: Request, { params }: { params: { questionId: string } }) {
  const supabase = await getSupabaseServer();
  const { error } = await supabase.from('questions').delete().eq('id', params.questionId);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
