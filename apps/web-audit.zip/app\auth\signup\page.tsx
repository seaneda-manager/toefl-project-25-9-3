/* apps/web/app/auth/signup/page.tsx */
import { redirect } from 'next/navigation';
import { signUp } from '@/actions/auth';
import type { ActionState } from '@/actions/auth';

export const dynamic = 'force-dynamic';

type Role = 'student' | 'teacher' | 'admin';

function normalizeRole(raw: FormDataEntryValue | null): Role {
  const r = String(raw ?? '').toLowerCase();
  return (['student', 'teacher', 'admin'] as Role[]).includes(r as Role)
    ? (r as Role)
    : 'student';
}

export default function SignUpPage({
  searchParams,
}: {
  searchParams?: Record<string, string | string[] | undefined>;
}) {
  async function signupAction(formData: FormData) {
    'use server';

    // role을 안전하게 보정해서 전달
    const role = normalizeRole(formData.get('role'));
    formData.set('role', role);

    const r = await signUp(formData);

    // ✅ 항상 ActionState로 매핑
    const mapped: ActionState = r.ok
      ? { ok: true, error: null }
      : { ok: false, error: r.error ?? 'Unknown error' };

    const email = String(formData.get('email') ?? '');

    if (mapped.ok) {
      // 가입 성공 → 로그인 페이지로. 이메일 프리필 + 성공 토스트용 쿼리
      redirect(`/auth/login?signup=success${email ? `&email=${encodeURIComponent(email)}` : ''}`);
    }

    // 실패 시 에러 메시지를 쿼리로 전달
    redirect(`/auth/signup?error=${encodeURIComponent(mapped.error ?? 'Unknown error')}${email ? `&email=${encodeURIComponent(email)}` : ''}`);
  }

  // 쿼리에서 기본값/오류 읽기
  const q = (k: string) => {
    const v = searchParams?.[k];
    return Array.isArray(v) ? v[0] : v ?? '';
  };
  const presetEmail = q('email');
  const errorMsg = q('error');

  return (
    <main className="mx-auto max-w-md px-6 py-10">
      <h1 className="text-2xl font-semibold mb-6">Create Account</h1>

      {errorMsg ? (
        <p className="mb-4 text-sm text-red-600">{errorMsg}</p>
      ) : null}

      <form action={signupAction} className="space-y-5">
        <div>
          <label className="block text-sm font-medium">Email</label>
          <input
            name="email"
            type="email"
            required
            defaultValue={presetEmail}
            className="mt-1 w-full rounded border px-3 py-2 bg-transparent"
            autoComplete="email"
          />
        </div>

        <div>
          <label className="block text-sm font-medium">Password</label>
          <input
            name="password"
            type="password"
            required
            minLength={6}
            className="mt-1 w-full rounded border px-3 py-2 bg-transparent"
            autoComplete="new-password"
          />
        </div>

        {/* 역할 선택 (user_metadata.role 로 저장됨) */}
        <fieldset>
          <legend className="block text-sm font-medium mb-2">Role</legend>
          <div className="flex items-center gap-5 text-sm">
            <label className="flex items-center gap-2">
              <input type="radio" name="role" value="student" defaultChecked />
              <span>Student</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="role" value="teacher" />
              <span>Teacher</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" name="role" value="admin" />
              <span>Admin</span>
            </label>
          </div>
        </fieldset>

        <button type="submit" className="rounded px-4 py-2 border w-full">
          Create Account
        </button>
      </form>
    </main>
  );
}
