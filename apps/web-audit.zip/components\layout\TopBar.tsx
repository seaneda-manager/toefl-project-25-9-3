import Link from "next/link";

export default function TopBar() {
  return (
    <header className="bg-neutral-100 text-neutral-900 border-b">
      <div className="container mx-auto h-12 px-4 flex items-center justify-between">
        {/* 좌측 로고 */}
        <div className="flex items-center gap-4">
          <Link href="/" className="font-bold tracking-tight">K-Prime</Link>
          <span className="h-4 w-px bg-neutral-300" />
          <Link href="/" className="font-semibold">Pier Academy</Link>
        </div>

        {/* 우측 액션 */}
        <nav className="flex items-center gap-2 text-sm">
          <Link href="/support" className="px-2 py-1 hover:underline">고객센터</Link>
          <Link href="/level-test" className="px-3 py-1.5 rounded-lg border bg-white hover:bg-neutral-50">
            레벨테스트
          </Link>
          <Link href="/signup" className="px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
            회원가입
          </Link>
        </nav>
      </div>
    </header>
  );
}
