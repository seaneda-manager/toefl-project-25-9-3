// apps/web/app/(protected)/reading/test/[sessionId]/p/[passageId]/page.tsx
import { getSupabaseServer } from '@/lib/supabaseServer';
import ReadingTestRunner from '@/components/reading/ReadingTestRunner';
import type { RPassage, RQuestion } from '@/types/types-reading';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

type RQType = RQuestion['type'];
const normalizeType = (t: any): RQType => {
  const ok: RQType[] = [
    'vocab','detail','negative_detail','paraphrasing','inference',
    'purpose','pronoun_ref','insertion','summary','organization'
  ];
  if (t === 'single') return 'detail';
  return ok.includes(t) ? (t as RQType) : 'detail';
};

export default async function Page({
  params,
}: { params: { sessionId: string; passageId: string } }) {
  const supabase = await getSupabaseServer();

  // passage 로드
  const { data: p } = await supabase
    .from('reading_passages')
    .select('*')
    .eq('id', params.passageId)
    .maybeSingle();
  if (!p) return <div className="p-6">Passage not found.</div>;

  // 질문/보기 로드
  const { data: qs } = await supabase
    .from('reading_questions')
    .select('*, choices:reading_choices(*)')
    .eq('passage_id', p.id)
    .order('number', { ascending: true });

  const passage: RPassage = {
    id: p.id,
    set_id: p.set_id ?? '',
    title: p.title ?? '',
    content: p.content ?? '',
    ui: p.ui ?? { paragraphSplit: 'auto' },
    questions: (qs ?? []).map((q: any) => ({
      id: q.id,
      passage_id: q.passage_id ?? p.id,
      number: q.number ?? 0,
      stem: q.stem ?? '',
      type: normalizeType(q.type),
      meta: q.meta ?? undefined,
      explanation: q.explanation ?? (q.clue_quote ? { clue_quote: q.clue_quote } : undefined),
      choices: (q.choices ?? []).map((c: any) => ({
        id: c.id,
        text: c.text ?? '',
        is_correct: !!c.is_correct,
        explain: c.explain ?? undefined,
      })),
    })),
  };

  // 이 Runner 시그니처는 프로젝트에 맞춰 이미 보정해둔 버전이어야 함
  return (
    <ReadingTestRunner
      passage={passage}
      sessionId={params.sessionId}
      onAnswer={async () => ({ ok: true })}
      onFinish={async () => ({ ok: true })}
    />
  );
}
