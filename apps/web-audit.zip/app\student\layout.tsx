// apps/web/app/student/layout.tsx
import { redirect } from 'next/navigation';
import { getSupabaseServer } from '@/lib/supabaseServer';

export const dynamic = 'force-dynamic';

export default async function Layout({ children }: { children: React.ReactNode }) {
  const supabase = await getSupabaseServer(); // ✅ await

  const { data: { user }, error: uerr } = await supabase.auth.getUser();
  if (uerr) redirect('/auth/login');
  if (!user) redirect('/auth/login');

  // 프로필에서 role 우선, 없으면 user_metadata.role 사용
  const { data: prof } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .maybeSingle<{ role: 'student' | 'teacher' | 'admin' }>();

  const role = (prof?.role ?? (user.user_metadata?.role as string | undefined)) || 'student';

  // 학생 전용 레이아웃: 교사/관리자는 다른 대시보드로 보냄
  if (role === 'teacher' || role === 'admin') {
    redirect('/teacher/dashboard'); // 필요하면 admin은 '/admin'으로 분기
  }

  return <>{children}</>;
}
