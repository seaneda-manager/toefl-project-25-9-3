export default function AdminDashboard(){
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Dashboard</h1>
      <p className="text-sm text-gray-500">콘텐츠 세트(Reading/Listening)를 생성하고 관리하세요.</p>
      <ul className="list-disc ml-5 text-sm">
        <li>왼쪽 네비게이션의 <b>Sets</b>에서 세트를 생성</li>
        <li>세트 내부에 지문/트랙, 문제, 보기를 차례대로 연결</li>
      </ul>
    </div>
  );
}
