import { NextResponse } from 'next/server';
import { getSupabaseServer } from '@/lib/supabaseServer';

export async function GET(_: Request, { params }: { params: { passageId: string } }) {
  const supabase = await getSupabaseServer();
  const { data, error } = await supabase
    .from('questions')
    .select('*')
    .eq('passage_id', params.passageId)
    .order('order_index', { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data ?? []);
}

export async function POST(req: Request, { params }: { params: { passageId: string } }) {
  const supabase = await getSupabaseServer();
  const body = await req.json(); // { number, type, stem, ... }
  const { data, error } = await supabase
    .from('questions')
    .insert({
      passage_id: params.passageId,
      set_id: body.set_id ?? null,
      number: body.number ?? 0,
      type: body.type,
      stem: body.stem,
      explanation: body.explanation ?? null,
      clue_quote: body.clue_quote ?? null,
      order_index: body.order_index ?? 0,
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data, { status: 201 });
}
