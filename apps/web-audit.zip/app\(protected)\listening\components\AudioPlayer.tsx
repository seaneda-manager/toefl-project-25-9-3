'use client';

type Props = { src: string };

function guessMime(src: string): string | undefined {
  const lower = src.split('?')[0].toLowerCase();
  if (lower.endsWith('.mp3')) return 'audio/mpeg';
  if (lower.endsWith('.ogg') || lower.endsWith('.oga')) return 'audio/ogg';
  if (lower.endsWith('.wav')) return 'audio/wav';
  return undefined;
}

export default function AudioPlayer({ src }: Props) {
  if (!src) {
    return (
      <div className="rounded border p-3 text-sm text-red-600">
        재생할 오디오 주소가 없습니다.
      </div>
    );
  }

  const mime = guessMime(src);

  return (
    <div className="rounded border p-3">
      <audio controls className="w-full" preload="metadata" aria-label="오디오 플레이어">
        <source src={src} type={mime} />
        브라우저가 오디오 요소를 지원하지 않습니다.
      </audio>
      <p className="mt-2 text-xs text-gray-500">
        오디오가 재생되지 않으면 새로고침 후 다시 시도해 주세요(브라우저 자동재생 정책의 영향일 수 있어요).
      </p>
    </div>
  );
}
