// apps/web/app/(protected)/admin/users/page.tsx
import UsersManager from "@/app/(protected)/admin/users/UsersManager";

export const dynamic = "force-dynamic"; // 목록 최신 반영

export default async function AdminUsersPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">User Management</h1>
        <p className="text-sm text-muted-foreground">
          검색, 역할 변경, 페이지네이션을 지원합니다.
        </p>
      </div>
      <UsersManager />
    </div>
  );
}
