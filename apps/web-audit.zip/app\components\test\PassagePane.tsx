﻿'use client'
export default function PassagePane({ content }: { content?: string }) {
return (
<article className="prose max-w-none whitespace-pre-wrap rounded-2xl border p-4">
{content ?? 'PassagePane placeholder ???ㅼ젣 蹂몃Ц??二쇱엯?섏꽭??'}
</article>
)
}
