// apps/web/app/types/types-cms.ts

export type ContentSet = {
  id: string;
  owner_id: string;
  title: string;
  section: 'reading' | 'listening' | 'speaking' | 'writing';
  level: string | null;
  tags: string[] | null;
  description: string | null;
  is_published: boolean;
  created_at: string;
  updated_at: string;
};

export type ContentSetInput = {
  title: string;
  section: ContentSet['section'];
  level?: string | null;
  tags?: string[] | null;
  description?: string | null;
  is_published?: boolean;
};

// (확장용: passages / questions / choices)
export type Passage = {
  id: string;
  set_id: string;
  title: string;
  content: string | null;
  order_index: number;
  created_at: string;
  updated_at: string;
};

export type Question = {
  id: string;
  set_id: string;
  passage_id: string | null;
  number: number;
  type:
    | 'vocab' | 'detail' | 'negative_detail' | 'paraphrasing' | 'insertion'
    | 'inference' | 'purpose' | 'pronoun_ref' | 'summary' | 'organization';
  stem: string;
  explanation: string | null;
  clue_quote: string | null;
  order_index: number;
  created_at: string;
  updated_at: string;
};

export type Choice = {
  id: string;
  question_id: string;
  text: string;
  is_correct: boolean;
  order_index: number;
  created_at: string;
  updated_at: string;
};
