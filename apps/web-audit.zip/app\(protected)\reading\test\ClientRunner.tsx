﻿// apps/web/app/(protected)/reading/test/ClientRunner.tsx
'use client';

import { useRouter } from 'next/navigation';
import TestRunner from './TestRunner';
import type { RPassage } from '@/types/types-reading';

export default function ClientRunner({ passage }: { passage: RPassage }) {
  const router = useRouter();

  return (
    <TestRunner
      passage={passage}
      onFinish={(sessionId: string) => router.push(`/reading/review/${sessionId}`)}
    />
  );
}
