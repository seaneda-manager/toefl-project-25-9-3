// apps/web/components/reading/metaAdapter.ts
import type { RQuestion } from '@/types/types-reading';

export type Target =
  | { mode: 'paragraph'; paragraph_index: number; arrow?: boolean }
  | { mode: 'insertion'; paragraph_index: number; anchors: string[] }
  | undefined;

/** meta 안전 뷰어 */
function viewMeta(q: RQuestion) {
  const paragraphHighlight = (q.meta?.paragraph_highlight ?? {}) as {
    paragraphs?: number[];
  };
  const insertion = (q.meta?.insertion ?? {}) as {
    anchors?: Array<string | number>;
  };
  return { paragraphHighlight, insertion };
}

export function targetFromMeta(q: RQuestion): Target {
  const { paragraphHighlight, insertion } = viewMeta(q);

  // 단락 하이라이트
  if (paragraphHighlight.paragraphs?.length) {
    const idxRaw = paragraphHighlight.paragraphs[0];
    const paragraph_index = Number.isFinite(idxRaw) ? (idxRaw as number) : 0;
    return { mode: 'paragraph', paragraph_index, arrow: true };
  }

  // 문장 삽입
  if (insertion.anchors?.length) {
    const anchors = insertion.anchors.map(String);
    // 삽입 문제는 보통 본문 전체 기준(0)에서 앵커 목록 사용
    return { mode: 'insertion', paragraph_index: 0, anchors };
  }

  return undefined;
}
