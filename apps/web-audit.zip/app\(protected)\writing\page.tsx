export default function WritingPage() {
return (
<div className="space-y-4">
<h1 className="text-2xl font-semibold">Writing</h1>
<div className="rounded-2xl border bg-white p-4">준비 중…</div>
</div>
);
}