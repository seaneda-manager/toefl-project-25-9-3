'use client';

import { useEffect, useState } from 'react';

type Profile = {
  id: string;
  email: string | null;
  full_name: string | null;
  role: 'student' | 'teacher' | 'admin';
  created_at: string | null;
};

type UsersResp = {
  items: Profile[];
  nextCursor?: string | null;
  prevCursor?: string | null;
  total?: number;
};

export default function UsersManager() {
  const [query, setQuery] = useState('');
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<UsersResp>({ items: [] });
  const [draftRole, setDraftRole] = useState<Record<string, Profile['role']>>({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [toast, setToast] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchList = async (c?: string) => {
    setLoading(true);
    setError(null);
    try {
      const url = new URL('/api/admin/users', window.location.origin);
      if (query) url.searchParams.set('q', query);
      if (c) url.searchParams.set('cursor', c);
      const res = await fetch(url.toString(), { cache: 'no-store' });
      if (!res.ok) throw new Error(await res.text());
      const json = (await res.json()) as UsersResp;
      setData(json);
      setCursor(c);
    } catch (e: any) {
      setError(e.message || 'Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchList(undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchList(undefined);
  };

  const applyRole = async (userId: string) => {
    const newRole = draftRole[userId];
    if (!newRole) return;
    setSaving((s) => ({ ...s, [userId]: true }));
    setError(null);
    setToast(null);
    try {
      const res = await fetch('/api/admin/set-role', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role: newRole }),
      });
      if (!res.ok) throw new Error(await res.text());
      setToast('역할이 저장되었습니다.');
      setData((d) => ({
        ...d,
        items: d.items.map((it) => (it.id === userId ? { ...it, role: newRole } : it)),
      }));
    } catch (e: any) {
      setError(e.message || 'Failed to set role');
    } finally {
      setSaving((s) => ({ ...s, [userId]: false }));
    }
  };

  const RoleSelect = ({ user }: { user: Profile }) => {
    const value = draftRole[user.id] ?? user.role;
    return (
      <div className="flex items-center gap-2">
        <select
          className="border rounded px-2 py-1"
          value={value}
          onChange={(e) =>
            setDraftRole((d) => ({ ...d, [user.id]: e.target.value as Profile['role'] }))
          }
        >
          <option value="student">student</option>
          <option value="teacher">teacher</option>
          <option value="admin">admin</option>
        </select>
        <button
          className="px-3 py-1 rounded border disabled:opacity-50"
          disabled={saving[user.id] || value === user.role}
          onClick={() => applyRole(user.id)}
        >
          {saving[user.id] ? 'Saving...' : 'Save'}
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <form onSubmit={onSearch} className="flex gap-2">
        <input
          className="border rounded px-3 py-2 flex-1"
          placeholder="이메일/이름 검색"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="border rounded px-4">Search</button>
      </form>

      {toast && <div className="text-green-600 text-sm">{toast}</div>}
      {error && <div className="text-red-600 text-sm">{error}</div>}

      <div className="overflow-x-auto rounded border">
        <table className="min-w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2">User</th>
              <th className="text-left px-3 py-2">Email</th>
              <th className="text-left px-3 py-2">Role</th>
              <th className="text-left px-3 py-2">Created</th>
              <th className="text-left px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td className="px-3 py-6" colSpan={5}>
                  Loading...
                </td>
              </tr>
            ) : data.items.length === 0 ? (
              <tr>
                <td className="px-3 py-6" colSpan={5}>
                  No users
                </td>
              </tr>
            ) : (
              data.items.map((u) => (
                <tr key={u.id} className="border-t">
                  <td className="px-3 py-2">{u.full_name ?? '-'}</td>
                  <td className="px-3 py-2">{u.email ?? '-'}</td>
                  <td className="px-3 py-2">{u.role}</td>
                  <td className="px-3 py-2">
                    {u.created_at ? new Date(u.created_at).toLocaleString() : '-'}
                  </td>
                  <td className="px-3 py-2">
                    <RoleSelect user={u} />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between">
        <button
          className="border rounded px-3 py-1 disabled:opacity-50"
          disabled={!data.prevCursor}
          onClick={() => fetchList(data.prevCursor!)}
        >
          Prev
        </button>
        <button
          className="border rounded px-3 py-1 disabled:opacity-50"
          disabled={!data.nextCursor}
          onClick={() => fetchList(data.nextCursor!)}
        >
          Next
        </button>
      </div>
    </div>
  );
}
