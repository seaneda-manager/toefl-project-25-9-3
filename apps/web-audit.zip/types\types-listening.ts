// apps/web/types/types-listening.ts
export type Mode = 'study' | 'test';

export interface ListeningChoice {
  id: string;
  text: string;
  /** 과거/현재 혼용 대응 */
  correct?: boolean;
  is_correct?: boolean;
}

export interface ListeningQuestion {
  id: string;
  number?: number;

  /** 과거 코드 호환용: 어떤 곳은 prompt, 어떤 곳은 stem을 씀 */
  prompt?: string;
  stem?: string;

  choices: ListeningChoice[];
  meta?: Record<string, unknown>;
}

export type LQuestion = ListeningQuestion;

export interface ListeningTrack {
  id: string;
  title?: string;

  /** 오디오 URL: 과거/현재 표기 모두 허용하되, 소비측에서 주로 audioUrl을 사용 */
  audioUrl: string;     // 주 사용 필드 (컴파일 오류 방지 위해 필수로 둠)
  audio_url?: string;   // 과거 표기(입력 호환)

  /** 시간 관련: 일부 코드에서 사용 */
  timeLimitSec?: number;
  durationSec?: number;

  questions: ListeningQuestion[];
}

/** ===== Helpers (호환용 유틸) ===== */

/** 질문 텍스트 통일 추출 */
export function getQuestionText(q: ListeningQuestion): string {
  return q.prompt ?? q.stem ?? '';
}

/** 오디오 URL 통일 추출 (data 측에서 audio_url만 넣어도 안전) */
export function getAudioUrl(t: ListeningTrack): string {
  return t.audioUrl ?? t.audio_url ?? '';
}

export function isChoiceCorrect(q: ListeningQuestion, choiceId: string) {
  return !!q.choices.find(
    (c) => c.id === choiceId && (c.correct === true || c.is_correct === true)
  );
}
