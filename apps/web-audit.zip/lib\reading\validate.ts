// apps/web/lib/reading/validate.ts
import type { RSet, RQuestion } from '@/types/types-reading';

/** 안전 뷰어: meta 내부를 타입 세이프하게 꺼내기 */
function viewMeta(q: RQuestion) {
  const summary = (q.meta?.summary ?? {}) as {
    candidates?: string[];
    correct?: number[];        // 정답 인덱스(0-based)
    selectionCount?: number;   // 선택 개수
  };
  const insertion = (q.meta?.insertion ?? {}) as {
    anchors?: Array<string | number>;
    correctIndex?: number;
  };
  const pronoun = (q.meta?.pronoun_ref ?? {}) as {
    pronoun?: string;
    referents?: string[];
    correctIndex?: number;
  };
  const paragraphHighlight = (q.meta?.paragraph_highlight ?? {}) as {
    paragraphs?: number[];
  };
  return { summary, insertion, pronoun, paragraphHighlight };
}

export function validateSet(s: RSet) {
  const errs: string[] = [];

  if (!s.passages?.length) errs.push('No passages.');

  s.passages?.forEach((p, pi) => {
    if (!p.title) errs.push(`P${pi + 1}: title missing`);
    if (!p.content) errs.push(`P${pi + 1}: content missing`);

    const nums = new Set<number>();

    (p.questions ?? []).forEach((q) => {
      // 번호 중복
      if (nums.has(q.number)) errs.push(`P${pi + 1} Q# dup: ${q.number}`);
      nums.add(q.number);

      const choices = q.choices ?? [];
      const { summary, insertion, pronoun } = viewMeta(q);

      // 단일 정답 유형: 정답 정확히 1개
      if (q.type !== 'summary' && q.type !== 'organization') {
        const corrects = choices.filter((c) => !!c.is_correct).length;
        if (corrects !== 1) {
          errs.push(
            `P${pi + 1} Q${q.number}: single-answer must have exactly 1 correct`
          );
        }
      }

      // insertion: anchors 개수 vs 보기 수 (anchors가 있으면 anchors 기준, 없으면 본문 [■] 마커 수 기준)
      if (q.type === 'insertion') {
        const choiceCount = choices.length;
        if (Array.isArray(insertion.anchors)) {
          const anchorCount = insertion.anchors.length;
          if (anchorCount !== choiceCount) {
            errs.push(
              `P${pi + 1} Q${q.number}: insertion anchors(${anchorCount}) != choices(${choiceCount})`
            );
          }
        } else {
          const markerCount = (p.content.match(/\[■\]/g) || []).length;
          if (markerCount !== choiceCount) {
            errs.push(
              `P${pi + 1} Q${q.number}: insertion anchors(${markerCount}) != choices(${choiceCount})`
            );
          }
        }
      }

      // summary: selectionCount & correct 개수, 보기 수 하한
      if (q.type === 'summary') {
        const sel = Number.isFinite(summary.selectionCount)
          ? (summary.selectionCount as number)
          : 3;

        // 메타에 correct 배열이 있으면 그 길이 사용, 없으면 choices의 is_correct 개수로 폴백
        const correctCount = Array.isArray(summary.correct)
          ? summary.correct.length
          : choices.filter((c) => !!c.is_correct).length;

        if (correctCount !== sel) {
          errs.push(`P${pi + 1} Q${q.number}: summary correct must be ${sel}`);
        }
        if (choices.length < sel * 2) {
          errs.push(
            `P${pi + 1} Q${q.number}: summary needs >= ${sel * 2} choices`
          );
        }
      }

      // pronoun_ref sanity
      if ((pronoun.referents?.length ?? 0) < 2) {
        errs.push(
          `P${pi + 1} Q${q.number}: pronoun_ref needs at least 2 referents`
        );
      }

      // explanation 왜 오답인지 키(id)들이 보기 id와 매칭되는지
      if (q.explanation?.why_others) {
        const ids = new Set(choices.map((c) => c.id));
        for (const id of Object.keys(q.explanation.why_others as Record<string, unknown>)) {
          if (!ids.has(id)) {
            errs.push(
              `P${pi + 1} Q${q.number}: why_others has unknown choice id "${id}"`
            );
          }
        }
      }
    });
  });

  return errs;
}
