﻿// apps/web/middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { createServerClient } from '@supabase/ssr';

const PROTECTED_PREFIXES = ['/home', '/learn', '/dashboard', '/admin'] as const;
const AUTH_ROUTES = [
  '/auth/login',
  '/auth/signup',
  '/auth/callback',
  '/auth/update-password',
  '/auth/update-password/callback',
];
const PUBLIC_FILE = /\.(.*)$/; // e.g. /images/a.png
const DEV_ALLOW = process.env.NEXT_PUBLIC_LEGACY_ALLOW === '1';

/** 라우트 그룹 제거 + 외부 URL 차단 + /auth 가드 */
function normalizePath(raw?: string | null) {
  let s = (typeof raw === 'string' ? raw : '') || '';
  try { s = decodeURIComponent(s); } catch {}
  s = s.trim();
  if (!s || s.includes('://')) return '/home';
  if (!s.startsWith('/')) s = `/${s}`;
  const groupHead = /^\/\([^/]+\)(?=\/|$)/;
  while (groupHead.test(s)) {
    s = s.replace(groupHead, '');
    if (!s) break;
  }
  if (s === '' || s === '/' || s.startsWith('/auth')) return '/home';
  return s;
}

function isProtected(pathname: string) {
  return PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + '/'));
}
function isAuthRoute(pathname: string) {
  return AUTH_ROUTES.some((p) => pathname === p || pathname.startsWith(p + '/'));
}

export async function middleware(req: NextRequest) {
  const url = req.nextUrl;
  const { pathname, search } = url;

  // 개발 중 teacher/legacy 우회 허용 (옵션)
  if (DEV_ALLOW && (pathname.startsWith('/teacher') || pathname.startsWith('/legacy'))) {
    return NextResponse.next();
  }

  // 정적/공용 파일은 통과
  if (
    PUBLIC_FILE.test(pathname) ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname === '/favicon.ico' ||
    pathname.startsWith('/assets/')
  ) {
    return NextResponse.next();
  }

  // ⚠️ 반드시 응답 객체를 만든 뒤, supabase가 여기에 쿠키 set/remove 할 수 있게 넘겨야 함
  const res = NextResponse.next();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return req.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: any) {
          try { res.cookies.set({ name, value, ...options }); } catch {}
        },
        remove(name: string, options: any) {
          try { res.cookies.set({ name, value: '', ...options, maxAge: 0 }); } catch {}
        },
      },
    }
  );

  // ✅ 실제 세션 조회 (쿠키 이름에 의존 X)
  const { data: { session } } = await supabase.auth.getSession();
  const isAuthed = !!session;

  // 보호 경로인데 미인증 → 로그인으로
  if (isProtected(pathname) && !isAuthed) {
    const loginUrl = url.clone();
    loginUrl.pathname = '/auth/login';
    loginUrl.searchParams.set('next', `${pathname}${search}`);
    return NextResponse.redirect(loginUrl);
  }

  // 인증 상태에서 /auth/* 접근 → next 또는 /home
  if (isAuthRoute(pathname) && isAuthed) {
    const nextRaw = url.searchParams.get('next');
    const safeTarget = normalizePath(nextRaw ?? '/home');
    return NextResponse.redirect(new URL(safeTarget, req.url));
  }

  // 기본 통과 (세션 갱신 쿠키가 있으면 res로 전달됨)
  return res;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|assets/|teacher/|legacy/).*)'],
};
