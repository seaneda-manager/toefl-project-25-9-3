// apps/web/app/(protected)/(teacher)/layout.tsx
import type { ReactNode } from 'react';
import { redirect } from 'next/navigation';
import TeacherTopTabs from '@/components/teacher/TeacherTopTabs';
import { requireTeacher } from '@/lib/auth/requireTeacher';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function TeacherLayout({ children }: { children: ReactNode }) {
  // 서버에서 권한 확인 (아니면 로그인/접근금지로 리다이렉트)
  try {
    await requireTeacher();
  } catch (e: any) {
    const msg = String(e?.message ?? '');
    if (msg.includes('Unauthorized')) redirect('/auth/login');
    redirect('/auth/forbidden');
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-6 space-y-4">
      <header className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Teacher Mode</h1>
        <TeacherTopTabs />
      </header>
      {children}
    </div>
  );
}
