// apps/web/lib/auth/requireTeacher.ts
'use server';

import { getSupabaseServer } from '@/lib/supabaseServer';

export type RoleFlags = {
  isTeacher: boolean;
  isAdmin?: boolean;
  canProduce?: boolean;
};

type ProfileRow = {
  role: 'student' | 'teacher' | 'admin' | null;
  is_admin: boolean | null;
  can_produce: boolean | null;
};

export async function requireTeacher(): Promise<RoleFlags> {
  const supabase = await getSupabaseServer(); // ✅ await

  const { data: { user }, error: userErr } = await supabase.auth.getUser();
  if (userErr) throw userErr;
  if (!user) throw new Error('Unauthorized: not signed in');

  const { data, error } = await supabase
    .from('profiles')
    .select('role, is_admin, can_produce')
    .eq('id', user.id)
    .maybeSingle<ProfileRow>();

  if (error) throw error;

  const isAdmin = !!data?.is_admin;
  const isTeacher = data?.role === 'teacher' || isAdmin;
  if (!isTeacher) throw new Error('Forbidden: teacher role required');

  return {
    isTeacher,
    isAdmin,
    canProduce: data?.can_produce ?? true,
  };
}
