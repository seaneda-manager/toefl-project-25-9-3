// apps/web/app/(protected)/listening/page.tsx
export const dynamic = 'force-dynamic';

import { getSupabaseServer } from '@/lib/supabaseServer';
import SetPicker from '@/components/listening/SetPicker';

type AvailSet = { id: string; tpo: number; title: string };

export default async function Page() {
  const supabase = await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    // (protected)라 거의 올 일 없지만 안전장치
    return <div className="p-6">Please sign in.</div>;
  }

  // ① RPC 권장 (예시)
  // const { data: sets, error } = await supabase
  //   .rpc<AvailSet[]>('listening_available_sets', { p_user_id: user.id });

  // ② 뷰/조인 직접 (현재 로직 유지)
  const { data: sets, error } = await supabase
    .from('v_user_listening_sets')
    .select('id,tpo,title')
    .eq('user_id', user.id)
    .eq('downloaded', true)
    .order('tpo', { ascending: true }) as unknown as { data: AvailSet[] | null, error: any };

  if (error) {
    return <div className="p-6 text-red-600">Load error: {error.message}</div>;
  }

  return (
    <div className="mx-auto max-w-xl p-6 space-y-4">
      <h1 className="text-xl font-semibold">Listening</h1>
      {(!sets || sets.length === 0) ? (
        <>
          <p className="text-sm text-neutral-600">
            다운로드된 TPO가 없습니다. 먼저 자료를 다운로드하세요.
          </p>
        </>
      ) : (
        <SetPicker sets={sets} />
      )}
      <p className="text-xs text-neutral-500">
        목록에는 다운로드 완료된 회차만 표시됩니다.
      </p>
    </div>
  );
}
