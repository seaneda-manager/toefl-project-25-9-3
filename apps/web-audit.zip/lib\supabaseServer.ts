﻿// apps/web/lib/supabaseServer.ts
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";

export async function getSupabaseServer() {
  // 🔧 await 사용
  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        // Server Component/Route Handler 모두 안전한 no-op (응답 쿠키는 별도 방식 필요)
        set(_name: string, _value: string, _options: any) { /* no-op */ },
        remove(_name: string, _options: any) { /* no-op */ },
      },
    }
  );

  return supabase;
}
