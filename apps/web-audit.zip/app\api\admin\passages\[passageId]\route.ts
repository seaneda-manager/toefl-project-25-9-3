import { NextResponse } from 'next/server';
import { getSupabaseServer } from '@/lib/supabaseServer';

export async function GET(_: Request, { params }: { params: { passageId: string } }) {
  const supabase = await getSupabaseServer();
  const { data, error } = await supabase.from('passages').select('*').eq('id', params.passageId).single();
  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  return NextResponse.json(data);
}

export async function PATCH(req: Request, { params }: { params: { passageId: string } }) {
  const supabase = await getSupabaseServer();
  const body = await req.json();
  const { data, error } = await supabase
    .from('passages')
    .update({
      title: body.title,
      content: body.content ?? null,
      order_index: body.order_index ?? 0,
    })
    .eq('id', params.passageId)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

export async function DELETE(_: Request, { params }: { params: { passageId: string } }) {
  const supabase = await getSupabaseServer();
  const { error } = await supabase.from('passages').delete().eq('id', params.passageId);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
