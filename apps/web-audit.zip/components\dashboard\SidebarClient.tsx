'use client';

import { useRouter, usePathname } from 'next/navigation';

export default function SidebarClient({ role }: { role: 'student' | 'teacher' }) {
  const router = useRouter();
  const pathname = usePathname();

  const Item = ({ href, children }: { href: string; children: React.ReactNode }) => {
    const active = pathname.startsWith(href);
    return (
      <button
        onClick={() => router.push(href)}
        className={`w-full text-left px-4 py-2.5 hover:bg-neutral-100 ${
          active ? 'bg-neutral-100 font-medium' : ''
        }`}
      >
        {children}
      </button>
    );
  };

  return (
    <nav className="py-3 text-sm">
      <div className="px-4 pb-2 text-xs uppercase tracking-wide text-neutral-500">Main</div>
      <Item href="/(protected)/home">Home</Item>
      <Item href="/(protected)/reading">Reading</Item>
      <Item href="/(protected)/listening">Listening</Item>
      <Item href="/(protected)/speaking">Speaking</Item>
      <Item href="/(protected)/writing">Writing</Item>

      {role === 'teacher' && (
        <>
          <div className="px-4 pt-4 pb-2 text-xs uppercase tracking-wide text-neutral-500">Teacher</div>
          <Item href="/(protected)/(teacher)">Teacher Home</Item>
          <Item href="/(protected)/(teacher)/students">Students</Item>
          <Item href="/(protected)/(teacher)/sets">Sets</Item>
        </>
      )}

      <div className="px-4 pt-4 pb-2 text-xs uppercase tracking-wide text-neutral-500">System</div>
      <Item href="/(protected)/settings">Settings</Item>
    </nav>
  );
}
