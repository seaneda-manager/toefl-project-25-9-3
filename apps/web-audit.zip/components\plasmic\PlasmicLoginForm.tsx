"use client";

import React from "react";
import Image from "next/image";

type Props = {
  email: string;
  password: string;
  remember: boolean;
  loading?: boolean;
  error?: string | null;
  onChangeEmail?: (v: string) => void;
  onChangePassword?: (v: string) => void;
  onToggleRemember?: (v: boolean) => void;
  onSubmit?: () => void;
  onFindId?: () => void;
  onForgotPw?: () => void;
};

export default function PlasmicLoginForm({
  email,
  password,
  remember,
  loading,
  error,
  onChangeEmail,
  onChangePassword,
  onToggleRemember,
  onSubmit,
  onFindId,
  onForgotPw,
}: Props) {
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!loading) onSubmit?.();
  }

  return (
    <div className="min-h-screen w-full bg-neutral-950 text-neutral-100 grid place-items-center p-4">
      <div className="w-full max-w-[960px] grid md:grid-cols-[420px_1fr] gap-6">
        {/* Left: Login card */}
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 shadow">
          <h1 className="text-xl font-semibold mb-1">로그인</h1>
          <p className="text-sm text-neutral-400 mb-4">
            아이디(이메일)와 비밀번호를 입력하세요.
          </p>

          <form className="space-y-4" onSubmit={handleSubmit} noValidate>
            <label className="block" htmlFor="email">
              <span className="block mb-1 text-sm text-neutral-300">아이디(이메일)</span>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={email}
                onChange={(e) => onChangeEmail?.(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-neutral-500"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                inputMode="email"
              />
            </label>

            <label className="block" htmlFor="password">
              <span className="block mb-1 text-sm text-neutral-300">비밀번호</span>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => onChangePassword?.(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-neutral-500"
                autoComplete="current-password"
              />
            </label>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm pt-1">
              <label className="inline-flex items-center gap-2 select-none" htmlFor="remember">
                <input
                  id="remember"
                  name="remember"
                  type="checkbox"
                  className="size-4 accent-white"
                  checked={remember}
                  onChange={(e) => onToggleRemember?.(e.target.checked)}
                />
                아이디 저장
              </label>
              <span className="opacity-40">|</span>
              <button
                type="button"
                className="underline underline-offset-4 hover:opacity-80"
                onClick={() => onFindId?.()}
              >
                아이디 찾기
              </button>
              <span className="opacity-40">|</span>
              <button
                type="button"
                className="underline underline-offset-4 hover:opacity-80"
                onClick={() => onForgotPw?.()}
              >
                비밀번호 찾기
              </button>
            </div>

            {error && (
              <div className="text-sm text-red-400" role="alert" aria-live="polite">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              aria-busy={loading || undefined}
              className="w-full py-2.5 rounded-xl bg-white text-black font-semibold hover:opacity-90 disabled:opacity-60"
            >
              {loading ? "로그인 중…" : "확인"}
            </button>
          </form>
        </div>

        {/* Right: Visual/help */}
        <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-6 md:min-h-[420px]">
          <div className="h-full grid place-items-center text-center">
            <div>
              <div className="mx-auto w-56 h-56 relative mb-4 opacity-90">
                <Image
                  src="/images/login-hero.png"
                  alt="학습 히어로 이미지"
                  fill
                  sizes="224px"
                  className="object-contain"
                  priority
                />
              </div>
              <h2 className="text-lg font-semibold">Klai Prime English</h2>
              <p className="text-sm text-neutral-400 mt-1">
                레이아웃/이미지는 Plasmic에서 바꾸고, 코드는 이 파일만 교체하면 됩니다.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
