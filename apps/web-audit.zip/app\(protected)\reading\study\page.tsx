﻿// apps/web/app/(protected)/reading/study/page.tsx
import { getSupabaseServer } from '@/lib/supabaseServer';
import StudyRunner from './StudyRunner';
import type { RPassage, RQuestion } from '@/types/types-reading';
type RQType = RQuestion['type'];

export default async function Page() {
  const supabase = await getSupabaseServer();

  const { data: p, error: pErr } = await supabase
    .from('reading_passages')
    .select('*')
    .order('ord', { ascending: false }) // created_at 없음 → ord로 최신 추정
    .limit(1)
    .maybeSingle();

  if (pErr) return <div>에러: {pErr.message}</div>;
  if (!p) return <div>Passage가 없습니다.</div>;

  const { data: qs } = await supabase
    .from('reading_questions')
    .select('*, choices:reading_choices(*)')
    .eq('passage_id', p.id)
    .order('number', { ascending: true });

  // RQType 정규화
  const normalizeType = (t: any): RQType => {
    const allowed: RQType[] = [
      'vocab',
      'detail',
      'negative_detail',
      'paraphrasing',
      'inference',
      'purpose',
      'pronoun_ref',
      'insertion',
      'summary',
      'organization',
    ];
    if (t === 'single') return 'detail';
    return allowed.includes(t) ? (t as RQType) : 'detail';
  };

  const passage: RPassage = {
    id: p.id,
    set_id: p.set_id ?? 'adhoc-set', // ✅ RPassage 필수 필드 보강
    title: p.title ?? '',
    content: p.content ?? '',
    ui: p.ui ?? { paragraphSplit: 'auto' },
    questions: (qs ?? []).map((q: any) => ({
      id: q.id,
      passage_id: q.passage_id ?? p.id, // ✅ 필수 필드 보강
      number: q.number ?? 0,
      type: normalizeType(q.type),
      stem: q.stem ?? '',
      meta: q.meta ?? undefined,
      explanation: q.explanation
        ? q.explanation
        : q.clue_quote
        ? { clue_quote: q.clue_quote }
        : undefined,
      choices: (q.choices ?? []).map((c: any) => ({
        id: c.id,
        text: c.text ?? c.label ?? '',
        is_correct: !!c.is_correct,
        explain: c.explain ?? undefined,
      })),
    })),
  };

  return <StudyRunner passage={passage} />;
}
