// apps/web/types/types-reading.ts
export interface RChoice {
  id: string;
  text: string;
  is_correct?: boolean;
  explain?: string | null;
  ord?: number;
  label?: string;
  meta?: unknown;
}

export interface RQuestion {
  id: string;
  passage_id?: string; // 에디터 단계에서 비어있을 수 있음
  number: number;
  type: string;
  stem: string;
  choices: RChoice[]; // 항상 배열로 취급해서 ?. 오류 제거
  meta?: {
    summary?: {
      selectionCount?: number;
      candidates?: string[];   // 각 보기 라벨/텍스트
      correct?: number[];      // 정답 인덱스 모음 (0-based)
    };
    insertion?: {
      anchors?: string[];
      correctIndex?: number;
    };
    pronoun_ref?: {
      pronoun?: string;
      referents?: string[];
      correctIndex?: number;
    };
    paragraph_highlight?: {
      paragraphs?: number[];
    };
  };
  explanation?: {
    clue_quote?: string;
    why_correct?: string;
    why_others?: Record<string, string>;
  };
  ord?: number;
}

export interface RPassage {
  id: string;
  set_id?: string; // 새로 추가할 때는 비어있을 수 있음
  title: string;
  content: string;
  ui?: {
    paragraphSplit?: string;
  };
  questions: RQuestion[];
  ord?: number;
}

export interface RSet {
  id: string;
  label: string;
  source?: string;
  version?: number | string | null; // number 허용
  passages: RPassage[];
}
