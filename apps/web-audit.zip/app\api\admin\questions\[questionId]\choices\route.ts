import { NextResponse } from 'next/server';
import { getSupabaseServer } from '@/lib/supabaseServer';

export async function GET(_: Request, { params }: { params: { questionId: string } }) {
  const supabase = await getSupabaseServer();
  const { data, error } = await supabase
    .from('choices')
    .select('*')
    .eq('question_id', params.questionId)
    .order('order_index', { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data ?? []);
}

export async function POST(req: Request, { params }: { params: { questionId: string } }) {
  const supabase = await getSupabaseServer();
  const body = await req.json(); // { text, is_correct, order_index? }
  const { data, error } = await supabase
    .from('choices')
    .insert({
      question_id: params.questionId,
      text: body.text,
      is_correct: !!body.is_correct,
      order_index: body.order_index ?? 0,
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data, { status: 201 });
}
