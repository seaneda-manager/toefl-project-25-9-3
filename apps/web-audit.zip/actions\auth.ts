/* apps/web/actions/auth.ts */
'use server';

import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { createServerClient } from '@supabase/ssr';

export type ActionState = {
  ok: boolean;
  error: string | null;
  redirectTo?: string;
};

export type Session = import('@supabase/supabase-js').Session;

function getSiteUrl() {
  const base = process.env.NEXT_PUBLIC_SUPABASE_SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3002';
  return base.replace(/\/$/, '');
}

/** 서버 액션 전용 Supabase 클라이언트 (쿠키 set/remove 가능) */
async function getSupabaseActionClient() {
  const cookieStore = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: any) {
          try { cookieStore.set({ name, value, ...options }); } catch {}
        },
        remove(name: string, options: any) {
          try { cookieStore.set({ name, value: '', ...options, maxAge: 0 }); } catch {}
        },
      },
    }
  );
}

/** 경로 정규화: 라우트 그룹 제거 + 안전 경로 보정 */
function normalizePublicPath(raw?: string | null) {
  let s = (typeof raw === 'string' ? raw : '') || '';

  // 1) URL 디코딩 (실패해도 무시)
  try { s = decodeURIComponent(s); } catch {}

  // 2) 공백 제거
  s = s.trim();

  // 3) 외부 URL 차단
  if (!s || s.includes('://')) return '/home';

  // 4) 반드시 / 시작
  if (!s.startsWith('/')) s = `/${s}`;

  // 5) 맨 앞 라우트 그룹들 반복적으로 제거: /(protected)/..., /(teacher)/..., …
  const groupHead = /^\/\([^/]+\)(?=\/|$)/;
  while (groupHead.test(s)) {
    s = s.replace(groupHead, '');
    if (!s) break;
  }

  // 6) /auth로 향하면 홈으로 (로그인 루프 방지)
  if (s === '' || s === '/' || s.startsWith('/auth')) return '/home';

  return s;
}

/** 현재 세션 조회 */
export async function getSession(): Promise<Session | null> {
  const supabase = await getSupabaseActionClient();
  const { data } = await supabase.auth.getSession();
  return data.session ?? null;
}

/** Email/Password 로그인 (성공 시 즉시 리다이렉트) */
export async function signInWithPassword(
  formDataOrCreds: FormData | { email: string; password: string }
): Promise<ActionState> {
  const email =
    typeof formDataOrCreds === 'object' && 'email' in formDataOrCreds
      ? formDataOrCreds.email
      : String((formDataOrCreds as FormData).get('email') ?? '').trim();

  const password =
    typeof formDataOrCreds === 'object' && 'password' in formDataOrCreds
      ? formDataOrCreds.password
      : String((formDataOrCreds as FormData).get('password') ?? '');

  if (!email || !password) return { ok: false, error: 'Email and password are required.' };

  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { ok: false, error: error.message };

  // 다음 경로 결정: FormData의 next 우선, 기본은 /home
  const nextRaw =
    (formDataOrCreds instanceof FormData ? (formDataOrCreds.get('next') as string | null) : null) ?? '/home';
  const next = normalizePublicPath(nextRaw);

  // ✅ 즉시 리다이렉트 (라우트 그룹 포함/인코딩돼도 정규화되어 실제 경로로 이동)
  redirect(next);
}

/** 비밀번호 재설정 메일 전송 */
export async function sendReset(formDataOrEmail: FormData | string): Promise<ActionState> {
  const email =
    typeof formDataOrEmail === 'string'
      ? formDataOrEmail
      : String(formDataOrEmail.get('email') ?? '').trim();

  if (!email) return { ok: false, error: 'Email is required.' };

  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    // 콜백은 /auth/update-password/callback
    redirectTo: `${getSiteUrl()}/auth/update-password/callback`,
  });
  if (error) return { ok: false, error: error.message };

  return {
    ok: true,
    error: null,
    redirectTo: `/auth/login?m=reset-sent&email=${encodeURIComponent(email)}`,
  };
}

/** 새 비밀번호 설정 */
export async function updatePassword(formData: FormData): Promise<ActionState> {
  const password = String(formData.get('password') ?? '');
  if (!password || password.length < 6) {
    return { ok: false, error: 'Password must be at least 6 characters.' };
  }
  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { ok: false, error: error.message };
  // 완료 후 로그인 페이지로
  return { ok: true, error: null, redirectTo: '/auth/login?m=password-updated' };
}

/** /auth/callback: 코드로 세션 교환 (필요 시 사용) */
export async function exchangeCodeForSession(authCode: string): Promise<ActionState> {
  if (!authCode) return { ok: false, error: 'Missing auth code.' };
  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.exchangeCodeForSession(authCode);
  if (error) return { ok: false, error: error.message };
  return { ok: true, error: null };
}

/** 회원가입(공통) */
export async function signUp(
  formData: FormData | { email: string; password: string; role?: string }
): Promise<ActionState> {
  const email =
    typeof formData === 'object' && 'email' in formData
      ? formData.email
      : String((formData as FormData).get('email') ?? '').trim();

  const password =
    typeof formData === 'object' && 'password' in formData
      ? formData.password
      : String((formData as FormData).get('password') ?? '');

  const role =
    typeof formData === 'object' && 'role' in formData
      ? ((formData as any).role as string | undefined)
      : (String((formData as FormData).get('role') ?? '') || undefined);

  if (!email || !password) return { ok: false, error: 'Email and password are required.' };

  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: role ? { role } : undefined },
  });

  if (error) return { ok: false, error: error.message };
  return { ok: true, error: null };
}

/** 교사 회원가입 (role=teacher 고정) */
export async function signUpTeacher(formData: FormData): Promise<ActionState> {
  const email = String(formData.get('email') ?? '').trim();
  const password = String(formData.get('password') ?? '');
  if (!email || !password) return { ok: false, error: 'Email and password are required.' };
  return await signUp({ email, password, role: 'teacher' });
}

/** 로그아웃 */
export async function signOut(): Promise<ActionState> {
  const supabase = await getSupabaseActionClient();
  const { error } = await supabase.auth.signOut();
  if (error) return { ok: false, error: error.message };
  return { ok: true, error: null, redirectTo: '/auth/login' };
}

/** 서버 액션용 즉시 리다이렉트 핸들러 (선택) */
export async function signOutAction(_: FormData) {
  const res = await signOut();
  redirect(res.redirectTo ?? '/auth/login');
}

/* ---- 호환용 별칭 (기존 코드 보호) ---- */
export async function signInEmailPassword(formData: FormData) {
  return signInWithPassword(formData);
}
export const signInWithPasswordAction = signInWithPassword;
