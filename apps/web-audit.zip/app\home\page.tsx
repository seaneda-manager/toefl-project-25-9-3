/* apps/web/app/home/page.tsx */
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { createServerClient } from '@supabase/ssr';

export const dynamic = 'force-dynamic';

type Role = 'student' | 'teacher' | 'admin';

function normalizeRole(raw: unknown): Role {
  const v = String(raw ?? '').trim().toLowerCase();
  if (v === 'teacher' || v === 'admin' || v === 'student') return v;
  return 'student';
}

function roleHome(role: Role) {
  switch (role) {
    case 'teacher': return '/home/teacher';
    case 'admin':   return '/home/admin';
    case 'student':
    default:        return '/home/student';
  }
}

export default async function HomeEntry() {
  const cookieStore = await cookies();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name) { return cookieStore.get(name)?.value; },
        set() {}, // 서버 컴포넌트에선 쿠키 갱신은 생략해도 무방
        remove() {},
      },
    }
  );

  // 1) 세션 존재 여부 확인
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    redirect('/auth/login?next=/home');
  }

  // 2) 최신 유저 메타데이터 재조회 (세션의 오래된 메타 방지)
  const { data: userData } = await supabase.auth.getUser();

  // 3) 우선순위: 최신 getUser → 세션
  const role = normalizeRole(
    userData?.user?.user_metadata?.role ?? session!.user.user_metadata?.role
  );

  redirect(roleHome(role));
}
