// server component (NO 'use client')
import { ReactNode } from 'react';
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { getSupabaseServer } from "@/lib/supabaseServer";
import TopbarClient from '@/components/dashboard/TopbarClient';
import SidebarClient from '@/components/dashboard/SidebarClient';

export default async function ProtectedLayout({ children }: { children: ReactNode }) {
  const supabase = await getSupabaseServer();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) redirect('/auth/login');

  const { data: { user } } = await supabase.auth.getUser();
  const email = user?.email ?? '';
  // TODO: profiles.role을 쓰면 실제 역할을 읽어오세요. 일단 student로 기본값.
  const role: 'student' | 'teacher' = 'student';

  return (
    <div className="min-h-screen grid grid-rows-[auto_1fr] bg-neutral-50 text-neutral-900">
      <div className="border-b bg-white">
        <TopbarClient email={email} />
      </div>
      <div className="grid grid-cols-[240px_1fr]">
        <aside className="border-r bg-white">
          <SidebarClient role={role} />
        </aside>
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
